"use strict";
var end;
(function (end) {
    class Person {
        constructor(_pos, _name) {
            this.balance = 0;
            this.position = _pos;
            this.name = _name;
        }
        draw() {
            //
        }
        move() {
            //
        }
        moveBack() {
            //
        }
        isOnBall() {
            return false;
        }
        playerCard(_vergleich) {
            //
        }
        change(_event) {
            //
        }
        substitute(_event) {
            //
        }
    }
    end.Person = Person;
})(end || (end = {}));
//# sourceMappingURL=Person.js.map